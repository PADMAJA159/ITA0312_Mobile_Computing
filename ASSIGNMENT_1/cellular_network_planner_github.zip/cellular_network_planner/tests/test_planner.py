import unittest
from cellular_planner.geometry import hex_cell_area,reuse_distance,valid_cluster_sizes
from cellular_planner.traffic import erlang_b,channels_for_blocking
from cellular_planner.recurrence import minimum_uniform_rounds
from cellular_planner.strategies import theoretical_sir_db

class PlannerTests(unittest.TestCase):
    def test_hex_area(self):
        self.assertAlmostEqual(hex_cell_area(1),2.598076,places=5)
    def test_reuse_distance(self):
        self.assertAlmostEqual(reuse_distance(1,7),21**0.5)
    def test_cluster_sizes(self):
        self.assertIn(7,valid_cluster_sizes(20)); self.assertIn(4,valid_cluster_sizes(20))
    def test_erlang_monotonic(self):
        self.assertLess(erlang_b(10,5),erlang_b(5,5))
    def test_required_channels(self):
        c=channels_for_blocking(5,.02)
        self.assertLessEqual(erlang_b(c,5),.02)
        if c: self.assertGreater(erlang_b(c-1,5),.02)
    def test_rounds(self):
        self.assertEqual(minimum_uniform_rounds(100,10),2)
    def test_sir_reference(self):
        self.assertAlmostEqual(theoretical_sir_db(7,4,6),18.67,delta=.15)

if __name__=="__main__":
    unittest.main()
